function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
}

async function waitForElement(selector, timeout = 15000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
        if (document.querySelector(selector)) return true;
        await sleep(500);
    }
    return false;
}

async function automateFeedback() {

    while (true) {

        let postBtn = Array.from(document.querySelectorAll('button'))
            .find(btn => btn.innerText.trim() === "Post");

        if (!postBtn) {
            alert("All feedback completed!");
            break;
        }

        postBtn.click();

        await waitForElement('input[type="radio"]');
        await sleep(2000);

        document.querySelectorAll('input[type="radio"]').forEach(el => {
            if (el.value == "5") el.click();
        });

        let textarea = document.querySelector('textarea');
        if (textarea) {
            textarea.value = "Good teaching and helpful explanations.";
        }

        await sleep(1000);

        let submitBtn = Array.from(document.querySelectorAll('button, input[type="submit"]'))
            .find(btn => btn.innerText?.toLowerCase().includes("submit"));

        if (submitBtn) submitBtn.click();

        await sleep(4000);

        window.history.back();

        await sleep(4000);
    }
}

automateFeedback();
